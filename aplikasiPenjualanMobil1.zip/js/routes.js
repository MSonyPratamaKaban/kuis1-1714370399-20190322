angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('akun', {
    url: '/page3',
    templateUrl: 'templates/akun.html',
    controller: 'akunCtrl'
  })

  .state('transaksi', {
    url: '/page2',
    templateUrl: 'templates/transaksi.html',
    controller: 'transaksiCtrl'
  })

  .state('home', {
    url: '/page1',
    templateUrl: 'templates/home.html',
    controller: 'homeCtrl'
  })

$urlRouterProvider.otherwise('/page3')


});